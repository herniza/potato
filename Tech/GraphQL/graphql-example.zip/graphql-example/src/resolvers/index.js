import postResolver from './postResolver';
import userResolver from './userResolver';

export default [userResolver, postResolver];